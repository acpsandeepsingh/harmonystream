// This file is intentionally left empty.
// The server-side Firebase Admin SDK could not be initialized due to missing environment credentials.
// All Firebase operations are handled on the client.
export {};

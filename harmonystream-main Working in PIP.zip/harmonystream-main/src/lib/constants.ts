export const LIKED_SONGS_PLAYLIST_ID = 'liked-songs';

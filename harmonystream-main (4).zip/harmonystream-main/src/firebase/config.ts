export const firebaseConfig = {
  "projectId": "studio-8258640677-40b59",
  "appId": "1:312831088099:web:e9129a94070e9cff033cd6",
  "apiKey": "AIzaSyAbHGZu-NdtvQhV_IkWh0htVgsSoIHam-s",
  "authDomain": "studio-8258640677-40b59.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "312831088099"
};
